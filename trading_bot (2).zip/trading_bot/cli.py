import argparse
from bot.orders import place_order
from bot.validators import validate_order
from bot.logging_config import setup_logging

def main():
    # Setup logging
    setup_logging()

    # CLI parser
    parser = argparse.ArgumentParser(description="Binance Futures Trading Bot")

    parser.add_argument("--symbol", required=True, help="Trading pair (e.g., BTCUSDT)")
    parser.add_argument("--side", required=True, choices=["BUY", "SELL"], help="Order side")
    parser.add_argument("--type", required=True, choices=["MARKET", "LIMIT"], help="Order type")
    parser.add_argument("--quantity", type=float, required=True, help="Order quantity")
    parser.add_argument("--price", type=float, help="Price (required for LIMIT orders)")

    args = parser.parse_args()

    try:
        # Validate input
        validate_order(
            args.symbol,
            args.side,
            args.type,
            args.quantity,
            args.price
        )

        print("\n🚀 Placing order...")
        print(f"Symbol: {args.symbol}")
        print(f"Side: {args.side}")
        print(f"Type: {args.type}")
        print(f"Quantity: {args.quantity}")
        if args.type == "LIMIT":
            print(f"Price: {args.price}")

        # Place order
        order = place_order(
            symbol=args.symbol,
            side=args.side,
            order_type=args.type,
            quantity=args.quantity,
            price=args.price
        )

        # Print result
        print("\n✅ Order Successful!")
        print("📌 Order Details:")
        print(f"Order ID: {order.get('orderId')}")
        print(f"Status: {order.get('status')}")
        print(f"Executed Quantity: {order.get('executedQty')}")
        print(f"Average Price: {order.get('avgPrice')}")

    except ValueError as ve:
        print(f"\n❌ Validation Error: {ve}")

    except Exception as e:
        print(f"\n❌ Error placing order: {e}")

if __name__ == "__main__":
    main()