# 📈 Binance Futures Trading Bot (Testnet)

## 🚀 Overview

This project is a Python-based CLI trading bot that interacts with the Binance Futures Testnet (USDT-M). It allows users to place MARKET and LIMIT orders with proper validation, logging, and error handling.

---

## 🛠️ Features

* ✅ Place **MARKET** and **LIMIT** orders
* ✅ Supports both **BUY** and **SELL**
* ✅ Command-line interface using argparse
* ✅ Input validation
* ✅ Structured modular code
* ✅ Logging of API requests, responses, and errors
* ✅ Error handling for invalid inputs and API failures

---

## 📂 Project Structure

```
trading_bot/
│
├── bot/
│   ├── client.py          # Binance API client setup
│   ├── orders.py          # Order placement logic
│   ├── validators.py      # Input validation
│   ├── logging_config.py  # Logging configuration
│
├── cli.py                 # CLI entry point
├── requirements.txt
├── README.md
├── bot.log                # Generated log file
```

---

## ⚙️ Setup Instructions

### 1. Clone the Repository

```
git clone <your-repo-link>
cd trading_bot
```

### 2. Create Virtual Environment (Optional but Recommended)

```
python -m venv venv
venv\Scripts\activate
```

### 3. Install Dependencies

```
pip install -r requirements.txt
```

---

## 🔑 API Setup (IMPORTANT)

1. Go to Binance Futures Testnet:
   👉 https://testnet.binancefuture.com

2. Register a new account

3. Create a **System Generated API Key**

4. Copy:

   * API Key
   * Secret Key

5. Add them in `bot/client.py`:

```python
API_KEY = "your_api_key"
API_SECRET = "your_secret_key"
```

---

## ▶️ How to Run

### 🔹 MARKET Order

```
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.002
```

---

### 🔹 LIMIT Order

```
python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.002 --price 80000
```

---

## 📌 Example Output

```
🚀 Placing order...
Symbol: BTCUSDT
Side: BUY
Type: MARKET
Quantity: 0.002

✅ Order Successful!
Order ID: 12345678
Status: NEW
Executed Quantity: 0.002
Average Price: 67000
```

---

## 📊 Logging

All API activity is logged in:

```
bot.log
```

Logs include:

* API requests
* API responses
* Errors

---

## ⚠️ Assumptions

* Minimum order value must be ≥ 100 USDT
* Testnet environment is used (no real money involved)
* API keys are correctly configured

---

## 🧪 Tested Scenarios

* ✅ Successful MARKET order
* ✅ Successful LIMIT order
* ✅ Invalid input handling
* ✅ API error handling

---

## 📦 Requirements

```
python-binance
```

---

## 📧 Submission

* GitHub Repository Link / Zip File
* Source Code
* README.md
* Log file (bot.log with sample orders)

---

## 🎯 Future Improvements (Optional)

* Add Stop-Limit or OCO orders
* Improve CLI UX with interactive prompts
* Add simple UI dashboard

---

## 👩‍💻 Author

Akanksha
